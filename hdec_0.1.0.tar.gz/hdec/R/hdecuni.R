#' @title hdecuni
#'
#' @description Función para tomar la decision de rechazar o no la Hipotesis Nula de una prueba de hipótesis unilateral.
#'
#' @param VC Valor Critico (Debe ser un numero)
#'
#' @param EP Valor del estadistico de prueba (Debe ser un numero)
#'
#' @return Decision de rechazar o no la Hipotesis Nula
#' @export
#'
#' @examples hdecuni(1.645,1.6)
#' @examples hdecuni(VC=1.645,EP=1.60)
hdecuni<-function(VC,EP){
  if (EP<VC){
    "No se puede rechazar Hipotesis Nula"
  } else {
    "Se puede rechazar Hipotesis Nula"
  }
}
