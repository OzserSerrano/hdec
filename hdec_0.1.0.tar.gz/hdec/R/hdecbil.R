#' @title hdecbil
#'
#' @description Función para tomar la decision de rechazar o no la Hipotesis Nula de una prueba de hipótesis bilateral.
#'
#' @param VC1 Valor Negativo del valor Critico (Debe ser un numero)
#'
#' @param VC2 Valor Positivo del valor Critico (Debe ser un numero)
#'
#' @param EP Valor del estadistico de prueba (Debe ser un numero)
#'
#' @return Decision de rechazar o no la Hipotesis Nula
#' @export
#'
#' @examples hdecbil(-1.645,1.645,1.6)
#' @examples hdecbil(VC1=-1.645,VC2=1.645,EP=1.60)
hdecbil<- function(VC1,VC2,EP) {
  if (EP<VC1)  {
    "No se puede rechazar Hipotesis Nula"
  } else if (EP>VC2) {
    "No Se puede rechazar Hipotesis Nula"
  }else {
    "Se puede rechazar Hipotesis Nula"
  }
}
